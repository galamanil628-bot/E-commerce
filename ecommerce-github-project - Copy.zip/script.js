const products=[
{id:1,name:"Laptop",price:50000},
{id:2,name:"Phone",price:20000},
{id:3,name:"Headphones",price:3000}
];
let cart=[];
const p=document.getElementById("products");
products.forEach(x=>p.innerHTML+=`<div class="product"><h3>${x.name}</h3><p>₹${x.price}</p><button onclick="add(${x.id})">Add to Cart</button></div>`);
function add(id){
 const item=products.find(a=>a.id===id);
 cart.push(item);
 document.getElementById("count").textContent=cart.length;
 let total=0;
 const ul=document.getElementById("cartItems");
 ul.innerHTML="";
 cart.forEach(i=>{total+=i.price;ul.innerHTML+=`<li>${i.name} - ₹${i.price}</li>`});
 document.getElementById("total").textContent=total;
}