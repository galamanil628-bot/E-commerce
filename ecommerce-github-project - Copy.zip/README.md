# Simple E-Commerce Website

## Files
- index.html
- style.css
- script.js

Open `index.html` in your browser to run the project.
